package nl.bioinf.idatabase.data_access;

import nl.bioinf.idatabase.model.Gene;

import java.util.List;

/**
 * Created by dvandeveerdonk on 6-3-17.
 * Interface for gene database
 */
public interface GeneDataSource {
    Gene getGeneByensId(String ensId);
    Gene getGeneByGeneName(String geneName);
    List<String> getGeneIds();
    List<String> getGeneNames();
}