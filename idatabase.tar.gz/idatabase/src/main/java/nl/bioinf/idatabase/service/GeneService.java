package nl.bioinf.idatabase.service;

import nl.bioinf.idatabase.data_access.GeneDataSource;
import nl.bioinf.idatabase.model.Gene;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by dvandeveerdonk on 8-3-17.
 */
@Service
public class GeneService {
    private final GeneDataSource geneDataSource;

    @Autowired
    public GeneService(GeneDataSource geneDataSource) {
        this.geneDataSource = geneDataSource;
    }

    public Gene getGene(String geneName, boolean useName){
        if (useName){
        return geneDataSource.getGeneByGeneName(geneName);
        }
        else{
            return geneDataSource.getGeneByensId(geneName);
        }
    }
    public List<String> getIds(){
        return geneDataSource.getGeneIds();
    }

    public List<String> getGeneNames() {
        return geneDataSource.getGeneNames();
    }

}
