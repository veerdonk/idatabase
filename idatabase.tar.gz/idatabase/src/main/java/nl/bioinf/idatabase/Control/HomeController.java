package nl.bioinf.idatabase.Control;

import com.google.gson.Gson;
import nl.bioinf.idatabase.service.GeneService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Locale;

/**
 * Created by dvandeveerdonk on 8-3-17.
 * Maps the requests for the home page
 * adds the current localization to the url
 * eg /en/home.html
 */

@Controller
public class HomeController {
    private final GeneService geneService;

    public HomeController(GeneService geneService) {
        this.geneService = geneService;
    }

    @RequestMapping(
            value = {"", "/", "home", "/home", "/home.html"})
            public String home(Locale locale){
        return "redirect:" + locale.getLanguage() + "/home";}

//    @RequestMapping(value = "/{locale}/home")
//    public String homeWithLocale(Model model) {
//        List<String> geneIds = geneService.getIds();
//        List<String> geneNames = geneService.getGeneNames();
//        Gson gson = new Gson();
//        String jsonNames = gson.toJson(geneNames);
//        System.out.println(jsonNames);
//        model.addAttribute("names", jsonNames);
//        return "home";
//    }

    @RequestMapping(value = "/{locale}/home",
            method = RequestMethod.GET,
            headers="Accept=*/*")
            public String getGeneNames(Model model) {
        List<String> geneNames = geneService.getGeneNames();
        Gson gson = new Gson();
        String jsonNames = gson.toJson(geneNames);
        model.addAttribute("names", jsonNames);
        return "home";

//        System.out.println(geneNames);
//        Gson gson = new Gson();
//        String jsonNames = gson.toJson(geneNames);
//        System.out.println(jsonNames);
//        return jsonNames;
    }



}
