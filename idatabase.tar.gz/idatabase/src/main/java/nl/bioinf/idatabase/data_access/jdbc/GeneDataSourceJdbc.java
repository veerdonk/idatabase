package nl.bioinf.idatabase.data_access.jdbc;


import nl.bioinf.idatabase.data_access.GeneDataSource;
import nl.bioinf.idatabase.model.Gene;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by dvandeveerdonk on 6-3-17.
 * Connects to the MySQL database to retrieve info
 * about genes
 */
@Component
public class GeneDataSourceJdbc implements GeneDataSource{

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public GeneDataSourceJdbc(JdbcTemplate jdbcTemplate, NamedParameterJdbcTemplate namedParameterJdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    /**
     * Searches the database for genes with the given
     * ensembl ID, returns an instance of the Gene class
     * @param ensId
     * @return
     */
    @Override
    public Gene getGeneByensId(String ensId) {
        return namedParameterJdbcTemplate.queryForObject("SELECT * FROM DE_genes WHERE ens_id =:ensId",
                new MapSqlParameterSource("ensId", ensId),
                BeanPropertyRowMapper.newInstance(Gene.class));
    }

    /**
     * Searches the database for Genes with given gene name
     * returns an instance of the Gene class
     * @param geneName
     * @return
     */
    @Override
    public Gene getGeneByGeneName(String geneName) {
        return namedParameterJdbcTemplate.queryForObject("SELECT * FROM DE_genes WHERE gene_name =:geneName",
                new MapSqlParameterSource("geneName", geneName),
                BeanPropertyRowMapper.newInstance(Gene.class));
    }

    @Override
    public List<String> getGeneIds() {
       List<String> names = jdbcTemplate.query("SELECT gene_name, ens_id FROM DE_genes", new RowMapper(){
           public Object mapRow(ResultSet resultSet, int i) throws SQLException{
              return resultSet.getString(1);
           }
       });
       return names;
    }

    @Override
    public List<String> getGeneNames() {
        List <String> geneNames = jdbcTemplate.queryForList("SELECT gene_name FROM DE_genes",
                String.class);
        return geneNames;
    }
}
