package nl.bioinf.idatabase.Control;

import nl.bioinf.idatabase.model.Gene;
import nl.bioinf.idatabase.service.GeneService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by dvandeveerdonk on 8-3-17.
 */
@Controller
public class GeneController {
    private final GeneService geneService;

    public GeneController(GeneService geneService) {
        this.geneService = geneService;
    }

    @RequestMapping("/{locale}/gene")
    public String geneResults(Model model, @RequestParam("id") String id){

//        System.out.println(id);
        geneService.getIds();
//        System.out.println(geneService.getGeneNames());

        Gene gene = geneService.getGene(id, true);
//        System.out.println(gene);

        model.addAttribute("gene", gene);
        return "/geneResults";
    }



//    @RequestMapping("/{locale}/gene")
//    public ModelAndView showGene(@ModelAttribute("gene")Gene gene)

}
