INSERT INTO DE_genes (id, stress_factor, timepoint, ens_id, log2fold, pval, gene_name) VALUES
('1', 'Aspergillus_fumigatus', '4h', 'ENSG00000001617', '1.17956368721867', '9.44249038744576e-19', 'SEMA3F'),
('2', 'Aspergillus_fumigatus', '4h', 'ENSG00000005020', '-1.39894513242005', '1.72371377570332e-28', 'SKAP2'),
('3', 'Aspergillus_fumigatus', '4h', 'ENSG00000006075', '2.127656079141', '1.36245534373431e-33', 'CCL3'),
('4', 'Aspergillus_fumigatus', '4h', 'ENSG00000006747', '2.66586413898889', '8.78960062942808e-22', 'SCIN'),
('5', 'Aspergillus_fumigatus', '4h', 'ENSG00000007350', '1.21340312402092', '2.68109685026999e-31', 'TKTP1');

