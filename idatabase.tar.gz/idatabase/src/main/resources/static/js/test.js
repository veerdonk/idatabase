/**
 * Created by dvandeveerdonk on 8-3-17.
 */
window.onload = function(){
    var json = JSON.parse(${names});
    alert(json);
}