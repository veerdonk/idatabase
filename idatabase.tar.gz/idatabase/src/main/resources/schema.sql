DROP TABLE IF EXISTS `DE_genes`;

CREATE TABLE `DE_genes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stress_factor` varchar(45) NOT NULL,
  `timepoint` varchar(3) NOT NULL,
  `ens_id` varchar(16) NOT NULL,
  `log2fold` double NOT NULL,
  `pval` double NOT NULL,
  `gene_name` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`));
